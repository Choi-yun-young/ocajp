package com.uni.project;

public class Project {

	private static void method1() {

		String str = "abc";

		System.out.println(str);

		String str1 = "abcd";

		System.out.println(str1);

		String str2 = "abcde";

		System.out.println(str2);
}
}